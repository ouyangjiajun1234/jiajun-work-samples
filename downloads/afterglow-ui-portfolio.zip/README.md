# Afterglow — interactive frontend portfolio demo

Original concept and frontend sample by Jiajun, designed and built with AI assistance. Fictional portfolio work, not a commissioned customer project.

## Open

Open index.html in Chrome or Edge. No install, login, internet connection, external font, paid API, or server is required. A local preview is also running at http://127.0.0.1:8771/ while this machine's server remains running.

## Try

- Switch between The garden, Moonlight and Daybreak.
- Send a message using Enter, the send button or a starter prompt. Shift+Enter makes a new line.
- Save a companion reply with “Keep this thought”, then open Little keepsakes.
- Saved notes and the room preference remain in the same browser's local storage. Conversation history resets on reload.
- On mobile, use the menu button to change rooms or open keepsakes.
- The information button explains the prototype's scope.

## Boundaries

Replies are scripted. No live model, production API, accounts, payments, analytics, client data or real customer testimonials are included. A production implementation requires a separate agreed scope for integration, privacy and acceptance testing. This portfolio sample is not evidence of paid income.

## Verified on 2026-10-03

Embedded JavaScript syntax; three theme switches; starter-prompt reply; saved-note view and persistence after refresh; custom-message submission; responsive 390×844 layout and mobile navigation. Temporary browser viewport override was reset after verification. Reduced-motion styles and keyboard-focus styles are included; full accessibility audit and backend testing are outside this demo.

Screenshots: garden-desktop.jpg, moonlight-desktop.jpg, daybreak-desktop.jpg, daybreak-mobile.jpg.

