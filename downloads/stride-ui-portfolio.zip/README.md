# Stride — sports-app UI and Lottie portfolio sample

Original fictional portfolio concept by Jiajun, created with AI assistance. Not a commissioned client project, customer testimonial, completed paid order or income.

## Open and try

Open index.html in Chrome or Edge. An internet connection is needed to load the free cdnjs lottie-web 5.13.0 player; the interface, data and original animation are otherwise included locally. No account, paid API or installation is required.

- Start session, pause/resume, then finish to see the Lottie confirmation.
- The saved session displays the timer's actual elapsed time. It is only retained during the current visit.
- Edit the weekly goal and inspect the sample progress change.
- Switch Overview/Sessions with the desktop or mobile navigation.
- Open motion-preview.html for play and frame controls.
- stride-session-complete.json is the original vector animation: 320×320, 30 fps, 90 frames, 3 seconds, 11 shape layers, no external image assets.

All weekly activity, route and planned sessions are illustrative. No GPS, sensor tracking, user accounts, payments, analytics, AI model, real exercise video or live customer data is connected.

## Verified 2026-10-03

Embedded JavaScript syntax and JSON structure; actual lottie-web SVG render with 11 paths and changing geometry between frames 20 and 52; completion state and final checkmark; timer pause/resume and saving actual 00:14 elapsed during a test; goal 120→150, progress caption 64 minutes remaining; mobile layout, no horizontal overflow at 375 CSS pixels (390×844 browser target including scrollbar), and mobile navigation. Temporary device and viewport overrides were cleared afterwards.

Included focus styles and reduced-motion treatment. Native Android/iOS playback, backend integration, full accessibility audit, and PAG/Spine/Rive conversion have not been verified.

## Dependency

[lottie-web](https://github.com/airbnb/lottie-web) is MIT licensed and loaded from [cdnjs bodymovin 5.13.0](https://cdnjs.com/libraries/bodymovin). The UI and animation JSON are original; the preview is not an After Effects/Bodymovin export claim.

